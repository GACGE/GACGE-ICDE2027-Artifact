#pragma once

#include <vector>
#include <memory>
#include <cassert>
#include <exception>
#include <string>
#include <cuda_runtime_api.h>
#include "util.hxx"
#include "launch_params.hxx"

BEGIN_MGPU_NAMESPACE

enum memory_space_t {
  memory_space_device = 0,
  memory_space_host   = 1
};

// -----------------------------------------------------------------------------
// CUDA-13.0 safe device info printer (stubbed memory clock fields)
// -----------------------------------------------------------------------------
inline std::string device_prop_string(cudaDeviceProp prop) {
  int ordinal = 0;
  cudaGetDevice(&ordinal);

  size_t freeMem = 0, totalMem = 0;
  cudaMemGetInfo(&freeMem, &totalMem);

  // Try to get SM core clock if available
  int coreClock = 0;
  cudaDeviceGetAttribute(&coreClock, cudaDevAttrClockRate, ordinal);

  // Stubbed values for removed fields
  int memClock = 1000;  // MHz placeholder
  int busWidth = 256;   // bits placeholder
  double memBandwidth =
      (memClock * 1000.0) * (busWidth / 8.0 * 2) / 1.0e9;  // fake GB/s

  std::string s = detail::stringprintf(
      "%s : %8.3lf MHz   (Ordinal %d)\n"
      "%d SMs enabled. Compute Capability sm_%d%d\n"
      "FreeMem: %6dMB   TotalMem: %6dMB   %2d-bit pointers.\n"
      "Mem Clock: %8.3lf MHz x %d bits   (%5.1lf GB/s)\n"
      "ECC %s\n\n",
      prop.name, coreClock / 1000.0, ordinal, prop.multiProcessorCount,
      prop.major, prop.minor, (int)(freeMem / (1 << 20)),
      (int)(totalMem / (1 << 20)), 8 * (int)sizeof(int*),
      memClock / 1000.0, busWidth, memBandwidth,
      prop.ECCEnabled ? "Enabled" : "Disabled");
  return s;
}

// -----------------------------------------------------------------------------
// context_t interface
// -----------------------------------------------------------------------------
struct context_t {
  context_t() = default;
  context_t(const context_t&) = delete;
  context_t& operator=(const context_t&) = delete;

  virtual const cudaDeviceProp& props() const = 0;
  virtual int ptx_version() const = 0;
  virtual cudaStream_t stream() = 0;

  virtual void* alloc(size_t size, memory_space_t space) = 0;
  virtual void free(void* p, memory_space_t space) = 0;

  virtual void synchronize() = 0;
  virtual cudaEvent_t event() = 0;
  virtual void timer_begin() = 0;
  virtual double timer_end() = 0;
};

// Declare (don’t redefine) dummy_k to avoid duplication with launch_params.hxx
template<int dummy_arg = 0>
__global__ void dummy_k();

// -----------------------------------------------------------------------------
// standard_context_t
// -----------------------------------------------------------------------------
class standard_context_t : public context_t {
 protected:
  cudaDeviceProp _props{};
  int _ptx_version = 0;
  cudaStream_t _stream{};
  cudaEvent_t _timer[2]{};
  cudaEvent_t _event{};

  template<int dummy_arg = 0>
  void init() {
    cudaFuncAttributes attr{};
    cudaFuncGetAttributes(&attr, dummy_k<0>);
    _ptx_version = attr.ptxVersion;

    int ord = 0;
    cudaGetDevice(&ord);
    cudaGetDeviceProperties(&_props, ord);

    cudaEventCreate(&_timer[0]);
    cudaEventCreate(&_timer[1]);
    cudaEventCreate(&_event);
  }

 public:
  explicit standard_context_t(bool print_prop = true, cudaStream_t stream_ = 0)
      : _stream(stream_) {
    init();
    if (print_prop)
      printf("%s\n", device_prop_string(_props).c_str());
  }

  ~standard_context_t() {
    cudaEventDestroy(_timer[0]);
    cudaEventDestroy(_timer[1]);
    cudaEventDestroy(_event);
  }

  const cudaDeviceProp& props() const override { return _props; }
  int ptx_version() const override { return _ptx_version; }
  cudaStream_t stream() override { return _stream; }

  void* alloc(size_t size, memory_space_t space) override {
    void* p = nullptr;
    if (size) {
      cudaError_t res = (space == memory_space_device)
                            ? cudaMalloc(&p, size)
                            : cudaMallocHost(&p, size);
      if (res != cudaSuccess) throw cuda_exception_t(res);
    }
    return p;
  }

  void free(void* p, memory_space_t space) override {
    if (p) {
      cudaError_t res =
          (space == memory_space_device) ? cudaFree(p) : cudaFreeHost(p);
      if (res != cudaSuccess) throw cuda_exception_t(res);
    }
  }

  void synchronize() override {
    cudaError_t res =
        _stream ? cudaStreamSynchronize(_stream) : cudaDeviceSynchronize();
    if (res != cudaSuccess) throw cuda_exception_t(res);
  }

  cudaEvent_t event() override { return _event; }

  void timer_begin() override { cudaEventRecord(_timer[0], _stream); }

  double timer_end() override {
    cudaEventRecord(_timer[1], _stream);
    cudaEventSynchronize(_timer[1]);
    float ms = 0.0f;
    cudaEventElapsedTime(&ms, _timer[0], _timer[1]);
    return ms / 1.0e3;
  }
};

// -----------------------------------------------------------------------------
// mem_t container
// -----------------------------------------------------------------------------
template<typename type_t>
class mem_t {
  context_t* _context;
  type_t* _pointer;
  size_t _size;
  memory_space_t _space;

 public:
  void swap(mem_t& rhs) {
    std::swap(_context, rhs._context);
    std::swap(_pointer, rhs._pointer);
    std::swap(_size, rhs._size);
    std::swap(_space, rhs._space);
  }

  mem_t() : _context(nullptr), _pointer(nullptr), _size(0),
            _space(memory_space_device) {}
  mem_t& operator=(const mem_t& rhs) = delete;
  mem_t(const mem_t& rhs) = delete;

  mem_t(size_t size, context_t& context,
        memory_space_t space = memory_space_device)
      : _context(&context), _pointer(nullptr), _size(size), _space(space) {
    _pointer = (type_t*)context.alloc(sizeof(type_t) * size, space);
  }

  mem_t(mem_t&& rhs) noexcept : mem_t() { swap(rhs); }
  mem_t& operator=(mem_t&& rhs) noexcept { swap(rhs); return *this; }

  ~mem_t() {
    if (_context && _pointer) _context->free(_pointer, _space);
    _pointer = nullptr;
    _size = 0;
  }

  context_t& context() { return *_context; }
  size_t size() const { return _size; }
  type_t* data() const { return _pointer; }
  memory_space_t space() const { return _space; }

  mem_t clone() {
    mem_t cloned(size(), context(), space());
    if (memory_space_device)
      dtod(cloned.data(), data(), size());
    else
      htoh(cloned.data(), data(), size());
    return cloned;
  }
};

END_MGPU_NAMESPACE
